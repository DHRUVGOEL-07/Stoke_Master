import fetch from 'node-fetch';

const BASE_URL = 'http://localhost:5000/api';
let token = '';

async function test() {
  try {
    // 1. Health Check
    console.log('\n🔍 Testing Health Check...');
    const health = await fetch('http://localhost:5000/health');
    console.log('✅', await health.json());

    // 2. Login
    console.log('\n🔐 Testing Login...');
    const loginRes = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'admin',
        password: 'admin123'
      })
    });
    const loginData = await loginRes.json();
    token = loginData.token;
    console.log('✅ Logged in as:', loginData.username);

    // 3. Get Products
    console.log('\n📦 Testing Get Products...');
    const productsRes = await fetch(`${BASE_URL}/products`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const products = await productsRes.json();
    console.log(`✅ Found ${products.length} products`);

    // 4. Get Locations
    console.log('\n📍 Testing Get Locations...');
    const locationsRes = await fetch(`${BASE_URL}/locations`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const locations = await locationsRes.json();
    console.log(`✅ Found ${locations.length} locations`);

    // 5. Get Stock
    console.log('\n📊 Testing Get Stock...');
    const stockRes = await fetch(`${BASE_URL}/stock`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const stock = await stockRes.json();
    console.log(`✅ Found ${stock.length} stock balances`);

    // 6. Get Dashboard
    console.log('\n📈 Testing Dashboard Stats...');
    const dashboardRes = await fetch(`${BASE_URL}/dashboard/stats`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const dashboard = await dashboardRes.json();
    console.log('✅ Dashboard Stats:', {
      totalProducts: dashboard.totalProducts,
      totalOnHand: dashboard.totalOnHand,
      pendingReceipts: dashboard.pendingReceipts,
      lowStockAlerts: dashboard.lowStockAlerts
    });

    console.log('\n🎉 ALL TESTS PASSED!\n');

  } catch (error) {
    console.error('❌ Test Failed:', error.message);
  }
}

test();