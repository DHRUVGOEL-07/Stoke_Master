import express from 'express';
import {
  getPickings,
  getPicking,
  createPicking,
  updatePicking,
  validatePicking,
  deletePicking,
} from '../controllers/picking.controller.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', protect, (req, res, next) => {
  req.query.type = 'internal';
  next();
}, getPickings);

router.get('/:id', protect, getPicking);

router.post('/', protect, (req, res, next) => {
  req.body.type = 'internal';
  next();
}, createPicking);

router.put('/:id', protect, updatePicking);
router.post('/:id/validate', protect, validatePicking);
router.delete('/:id', protect, deletePicking);

export default router;