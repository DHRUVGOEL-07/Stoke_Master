import express from 'express';
import { Op } from 'sequelize';
import StockMove from '../models/StockMove.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', protect, async (req, res) => {
  try {
    const { product_id, location_id, startDate, endDate, type } = req.query;
    const where = {};
    
    if (product_id) where.product_id = product_id;
    if (type) where.type = type;
    if (location_id) {
      where[Op.or] = [{ src_id: location_id }, { dest_id: location_id }];
    }
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt[Op.gte] = new Date(startDate);
      if (endDate) where.createdAt[Op.lte] = new Date(endDate);
    }

    const moves = await StockMove.findAll({
      where,
      include: [
        { association: 'product', attributes: ['id', 'name', 'sku'] },
        { association: 'src', attributes: ['id', 'name'] },
        { association: 'dest', attributes: ['id', 'name'] },
        { association: 'picking', attributes: ['id', 'reference', 'type'] }
      ],
      order: [['createdAt', 'DESC']],
      limit: 1000,
    });

    res.json(moves);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;