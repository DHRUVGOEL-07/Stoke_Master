import express from 'express';
import { Op, fn, col, literal } from 'sequelize';
import Product from '../models/Product.js';
import StockBalance from '../models/StockBalance.js';
import Picking from '../models/Picking.js';
import StockMove from '../models/StockMove.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/stats', protect, async (req, res) => {
  try {
    const totalProducts = await Product.count();

    const totalStockResult = await StockBalance.findOne({
      attributes: [[fn('SUM', col('qty')), 'totalQty']]
    });
    const totalOnHand = totalStockResult?.dataValues.totalQty || 0;

    const pendingReceipts = await Picking.count({ 
      where: { type: 'incoming', status: { [Op.ne]: 'done' } } 
    });
    
    const pendingDeliveries = await Picking.count({ 
      where: { type: 'outgoing', status: { [Op.ne]: 'done' } } 
    });

    const pendingTransfers = await Picking.count({ 
      where: { type: 'internal', status: { [Op.ne]: 'done' } } 
    });

    const lowStockProducts = await Product.findAll({
      attributes: [
        'id', 'name', 'sku', 'min_qty',
        [fn('COALESCE', fn('SUM', col('stockBalances.qty')), 0), 'totalStock']
      ],
      include: [{
        model: StockBalance,
        as: 'stockBalances',
        attributes: [],
        required: false
      }],
      group: ['Product.id'],
      having: literal('COALESCE(SUM(stockBalances.qty), 0) < Product.min_qty'),
      raw: true
    });

    const recentMoves = await StockMove.findAll({
      limit: 10,
      order: [['createdAt', 'DESC']],
      include: ['product', 'picking']
    });

    res.json({
      totalProducts,
      totalOnHand,
      pendingReceipts,
      pendingDeliveries,
      pendingTransfers,
      lowStockAlerts: lowStockProducts.length,
      lowStockProducts,
      recentMoves,
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ message: error.message });
  }
});

export default router;