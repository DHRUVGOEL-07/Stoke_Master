import express from 'express';
import { getStockView, getStockByProduct } from '../controllers/stock.controller.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.get('/', protect, getStockView);
router.get('/by-product', protect, getStockByProduct);

export default router;