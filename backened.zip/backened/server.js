import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { connectDB } from './config/db.js';
import { generatePickingPDF } from './controllers/pdf.controller.js';
import { protect } from './middleware/authMiddleware.js';

// Routes
import authRoutes from './routes/auth.js';
import productRoutes from './routes/products.js';
import locationRoutes from './routes/locations.js';
import pickingRoutes from './routes/pickings.js';
import incomingRoutes from './routes/incoming.js';
import outgoingRoutes from './routes/outgoing.js';
import internalRoutes from './routes/internal.js';
import stockRoutes from './routes/stock.js';
import ledgerRoutes from './routes/ledger.js';
import dashboardRoutes from './routes/dashboard.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

connectDB();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/locations', locationRoutes);
app.use('/api/pickings', pickingRoutes);
app.use('/api/receipts', incomingRoutes);
app.use('/api/deliveries', outgoingRoutes);
app.use('/api/transfers', internalRoutes);
app.use('/api/stock', stockRoutes);
app.use('/api/ledger', ledgerRoutes);
app.use('/api/dashboard', dashboardRoutes);

// PDF generation
app.get('/api/pickings/:id/pdf', protect, generatePickingPDF);
app.get('/api/receipts/:id/pdf', protect, generatePickingPDF);
app.get('/api/deliveries/:id/pdf', protect, generatePickingPDF);
app.get('/api/transfers/:id/pdf', protect, generatePickingPDF);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'StockMaster API - SQLite Ready' });
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.statusCode || 500).json({
    message: err.message || 'Internal Server Error',
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📊 Database: SQLite`);
  console.log(`🌐 Environment: ${process.env.NODE_ENV}`);
});