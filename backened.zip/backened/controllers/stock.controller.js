import { Op, fn, col } from 'sequelize';
import StockBalance from '../models/StockBalance.js';

export const getStockView = async (req, res) => {
  try {
    const { product_id, location_id } = req.query;
    const where = {};

    if (product_id) where.product_id = product_id;
    if (location_id) where.location_id = location_id;

    const stocks = await StockBalance.findAll({
      where,
      include: [
        { association: 'product', attributes: ['id', 'name', 'sku', 'unit'] },
        { association: 'location', attributes: ['id', 'name', 'type'] }
      ],
      order: [['product_id', 'ASC']],
    });

    res.json(stocks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getStockByProduct = async (req, res) => {
  try {
    const stocks = await StockBalance.findAll({
      attributes: [
        'product_id',
        [fn('SUM', col('qty')), 'total_qty'],
        [fn('SUM', col('reserved')), 'total_reserved']
      ],
      include: [
        { association: 'product', attributes: ['id', 'name', 'sku', 'min_qty'] }
      ],
      group: ['product_id', 'product.id'],
      raw: false,
    });

    res.json(stocks);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};