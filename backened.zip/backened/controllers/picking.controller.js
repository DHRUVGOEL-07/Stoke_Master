import { sequelize } from '../config/db.js';
import Picking from '../models/Picking.js';
import PickingLine from '../models/PickingLine.js';
import StockBalance from '../models/StockBalance.js';
import StockMove from '../models/StockMove.js';

export const getPickings = async (req, res) => {
  try {
    const { type } = req.query;
    const where = type ? { type } : {};

    const pickings = await Picking.findAll({
      where,
      include: [
        {
          association: 'lines',
          include: ['product', 'source', 'dest']
        },
        { association: 'creator', attributes: ['username'] }
      ],
      order: [['createdAt', 'DESC']],
    });
    res.json(pickings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const getPicking = async (req, res) => {
  try {
    const picking = await Picking.findByPk(req.params.id, {
      include: [
        {
          association: 'lines',
          include: ['product', 'source', 'dest']
        },
        { association: 'creator', attributes: ['username'] }
      ]
    });
    
    if (!picking) {
      return res.status(404).json({ message: 'Picking not found' });
    }
    
    res.json(picking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const createPicking = async (req, res) => {
  const transaction = await sequelize.transaction();
  
  try {
    const { type, partner, scheduled_date, notes, lines } = req.body;
    
    const picking = await Picking.create({
      type,
      partner,
      scheduled_date,
      notes,
      created_by: req.user.id,
    }, { transaction });

    for (const line of lines) {
      await PickingLine.create({
        picking_id: picking.id,
        product_id: line.product_id,
        description: line.description,
        qty_demand: line.qty_demand,
        qty_done: line.qty_done || 0,
        source_id: line.source_id,
        dest_id: line.dest_id,
      }, { transaction });
    }

    await transaction.commit();

    const createdPicking = await Picking.findByPk(picking.id, {
      include: [{ association: 'lines', include: ['product', 'source', 'dest'] }]
    });

    res.status(201).json(createdPicking);
  } catch (error) {
    await transaction.rollback();
    res.status(500).json({ message: error.message });
  }
};

export const validatePicking = async (req, res) => {
  const transaction = await sequelize.transaction();
  
  try {
    const picking = await Picking.findByPk(req.params.id, {
      include: [{ association: 'lines' }]
    });
    
    if (!picking) {
      await transaction.rollback();
      return res.status(404).json({ message: 'Picking not found' });
    }

    if (picking.status === 'done') {
      await transaction.rollback();
      return res.status(400).json({ message: 'Already validated' });
    }

    for (const line of picking.lines) {
      const { product_id, qty_done, source_id, dest_id } = line;

      if (qty_done <= 0) continue;

      // Subtract from source
      if (source_id) {
        let sourceStock = await StockBalance.findOne({
          where: { product_id, location_id: source_id },
          transaction
        });

        if (!sourceStock || sourceStock.qty < qty_done) {
          await transaction.rollback();
          return res.status(400).json({ message: 'Insufficient stock' });
        }

        await sourceStock.update({ qty: sourceStock.qty - qty_done }, { transaction });
      }

      // Add to destination
      if (dest_id) {
        let destStock = await StockBalance.findOne({
          where: { product_id, location_id: dest_id },
          transaction
        });

        if (!destStock) {
          destStock = await StockBalance.create({
            product_id,
            location_id: dest_id,
            qty: qty_done,
            reserved: 0
          }, { transaction });
        } else {
          await destStock.update({ qty: parseFloat(destStock.qty) + parseFloat(qty_done) }, { transaction });
        }
      }

      // Create stock move
      await StockMove.create({
        product_id,
        qty: qty_done,
        src_id: source_id,
        dest_id: dest_id,
        picking_id: picking.id,
        reference: picking.reference,
        type: picking.type,
      }, { transaction });
    }

    await picking.update({ status: 'done' }, { transaction });
    await transaction.commit();

    const validatedPicking = await Picking.findByPk(picking.id, {
      include: [{ association: 'lines', include: ['product', 'source', 'dest'] }]
    });

    res.json(validatedPicking);
  } catch (error) {
    await transaction.rollback();
    res.status(500).json({ message: error.message });
  }
};

export const updatePicking = async (req, res) => {
  try {
    const picking = await Picking.findByPk(req.params.id);
    
    if (!picking) {
      return res.status(404).json({ message: 'Picking not found' });
    }

    if (picking.status === 'done') {
      return res.status(400).json({ message: 'Cannot update validated picking' });
    }

    await picking.update(req.body);
    
    const updatedPicking = await Picking.findByPk(picking.id, {
      include: [{ association: 'lines', include: ['product', 'source', 'dest'] }]
    });
    
    res.json(updatedPicking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const deletePicking = async (req, res) => {
  try {
    const picking = await Picking.findByPk(req.params.id);
    
    if (!picking) {
      return res.status(404).json({ message: 'Picking not found' });
    }

    if (picking.status === 'done') {
      return res.status(400).json({ message: 'Cannot delete validated picking' });
    }

    await picking.destroy();
    res.json({ message: 'Picking deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};