import puppeteer from 'puppeteer';
import ejs from 'ejs';
import path from 'path';
import { fileURLToPath } from 'url';
import Picking from '../models/Picking.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const generatePickingPDF = async (req, res) => {
  try {
    const picking = await Picking.findByPk(req.params.id, {
      include: [
        {
          association: 'lines',
          include: ['product', 'source', 'dest']
        },
        { association: 'creator', attributes: ['username'] }
      ]
    });

    if (!picking) {
      return res.status(404).json({ message: 'Picking not found' });
    }

    const templatePath = path.join(__dirname, '../templates/picking.ejs');
    const html = await ejs.renderFile(templatePath, { picking });

    const browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    
    const pdf = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '20px', bottom: '20px', left: '20px', right: '20px' }
    });
    
    await browser.close();

    res.contentType('application/pdf');
    res.send(pdf);
  } catch (error) {
    console.error('PDF Generation Error:', error);
    res.status(500).json({ message: error.message });
  }
};