import dotenv from 'dotenv';
import { sequelize, connectDB } from './config/db.js';
import User from './models/User.js';
import Product from './models/Product.js';
import Location from './models/Location.js';
import StockBalance from './models/StockBalance.js';
import Picking from './models/Picking.js';
import PickingLine from './models/PickingLine.js';

dotenv.config();

const seedData = async () => {
  try {
    await connectDB();

    await sequelize.sync({ force: true });
    console.log('🗑️  Database reset');

    // Create users
    const admin = await User.create({
      username: 'admin',
      email: 'admin@stockmaster.local',
      password: 'admin123',
      role: 'admin',
    });

    const user = await User.create({
      username: 'user',
      email: 'user@stockmaster.local',
      password: 'user123',
      role: 'user',
    });

    console.log('✅ Users created');

    // Create locations
    const warehouse = await Location.create({ name: 'Main Warehouse', type: 'internal' });
    const showroom = await Location.create({ name: 'Showroom', type: 'internal' });
    const storage = await Location.create({ name: 'Storage Room', type: 'internal' });
    const suppliers = await Location.create({ name: 'Suppliers', type: 'supplier' });
    const customers = await Location.create({ name: 'Customers', type: 'customer' });

    console.log('✅ Locations created');

    // Create products
    const products = await Product.bulkCreate([
      { name: 'Laptop Dell XPS 13', sku: 'LAP-001', min_qty: 5, unit: 'Units', cost_price: 1200 },
      { name: 'iPhone 15 Pro', sku: 'PHN-001', min_qty: 10, unit: 'Units', cost_price: 999 },
      { name: 'Samsung Monitor 27"', sku: 'MON-001', min_qty: 8, unit: 'Units', cost_price: 299 },
      { name: 'Wireless Mouse Logitech', sku: 'MOU-001', min_qty: 20, unit: 'Units', cost_price: 29 },
      { name: 'Mechanical Keyboard RGB', sku: 'KEY-001', min_qty: 15, unit: 'Units', cost_price: 89 },
      { name: 'USB-C Hub 7-in-1', sku: 'HUB-001', min_qty: 25, unit: 'Units', cost_price: 45 },
      { name: 'Webcam HD 1080p', sku: 'CAM-001', min_qty: 12, unit: 'Units', cost_price: 79 },
      { name: 'Headphones Sony WH-1000XM5', sku: 'HPH-001', min_qty: 10, unit: 'Units', cost_price: 349 },
    ]);

    console.log('✅ Products created');

    // Create initial stock
    for (let i = 0; i < products.length; i++) {
      await StockBalance.create({
        product_id: products[i].id,
        location_id: warehouse.id,
        qty: (i + 1) * 10,
        reserved: 0,
      });
    }

    console.log('✅ Stock balances created');

    // Create sample picking
    const receipt = await Picking.create({
      type: 'incoming',
      partner: 'Tech Supplies Inc.',
      scheduled_date: new Date(),
      status: 'draft',
      notes: 'Monthly stock replenishment',
      created_by: admin.id,
    });

    await PickingLine.bulkCreate([
      {
        picking_id: receipt.id,
        product_id: products[0].id,
        qty_demand: 10,
        qty_done: 0,
        source_id: suppliers.id,
        dest_id: warehouse.id,
      },
      {
        picking_id: receipt.id,
        product_id: products[1].id,
        qty_demand: 20,
        qty_done: 0,
        source_id: suppliers.id,
        dest_id: warehouse.id,
      },
    ]);

    console.log('✅ Sample data created');

    console.log('\n========================================');
    console.log('✅ SEED COMPLETED SUCCESSFULLY!');
    console.log('========================================');
    console.log('\n📝 LOGIN CREDENTIALS:\n');
    console.log('Admin:');
    console.log('  Username: admin');
    console.log('  Password: admin123\n');
    console.log('User:');
    console.log('  Username: user');
    console.log('  Password: user123\n');
    console.log('========================================\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seed Error:', error);
    process.exit(1);
  }
};

seedData();