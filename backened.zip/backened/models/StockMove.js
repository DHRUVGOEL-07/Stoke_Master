import { DataTypes } from 'sequelize';
import { sequelize } from '../config/db.js';
import Product from './Product.js';
import Location from './Location.js';
import Picking from './Picking.js';

const StockMove = sequelize.define('StockMove', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  product_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  qty: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  src_id: {
    type: DataTypes.INTEGER,
  },
  dest_id: {
    type: DataTypes.INTEGER,
  },
  picking_id: {
    type: DataTypes.INTEGER,
  },
  reference: {
    type: DataTypes.STRING,
  },
  type: {
    type: DataTypes.ENUM('incoming', 'outgoing', 'internal'),
  },
}, {
  tableName: 'stock_moves',
  timestamps: true,
});

StockMove.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });
StockMove.belongsTo(Location, { foreignKey: 'src_id', as: 'src' });
StockMove.belongsTo(Location, { foreignKey: 'dest_id', as: 'dest' });
StockMove.belongsTo(Picking, { foreignKey: 'picking_id', as: 'picking' });

export default StockMove;