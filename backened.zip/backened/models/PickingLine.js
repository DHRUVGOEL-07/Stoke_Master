import { DataTypes } from 'sequelize';
import { sequelize } from '../config/db.js';
import Picking from './Picking.js';
import Product from './Product.js';
import Location from './Location.js';

const PickingLine = sequelize.define('PickingLine', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  picking_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  product_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
  },
  qty_demand: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  qty_done: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
  source_id: {
    type: DataTypes.INTEGER,
  },
  dest_id: {
    type: DataTypes.INTEGER,
  },
}, {
  tableName: 'picking_lines',
  timestamps: true,
});

PickingLine.belongsTo(Picking, { foreignKey: 'picking_id', as: 'picking', onDelete: 'CASCADE' });
PickingLine.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });
PickingLine.belongsTo(Location, { foreignKey: 'source_id', as: 'source' });
PickingLine.belongsTo(Location, { foreignKey: 'dest_id', as: 'dest' });

Picking.hasMany(PickingLine, { foreignKey: 'picking_id', as: 'lines' });

export default PickingLine;