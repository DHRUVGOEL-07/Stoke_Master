import { DataTypes } from 'sequelize';
import { sequelize } from '../config/db.js';

const Product = sequelize.define('Product', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  sku: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  description: {
    type: DataTypes.TEXT,
  },
  unit: {
    type: DataTypes.STRING,
    defaultValue: 'Units',
  },
  min_qty: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
  },
  cost_price: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
}, {
  tableName: 'products',
  timestamps: true,
  hooks: {
    beforeSave: (product) => {
      if (product.sku) {
        product.sku = product.sku.toUpperCase();
      }
    },
  },
});

export default Product;