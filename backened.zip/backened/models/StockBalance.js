import { DataTypes } from 'sequelize';
import { sequelize } from '../config/db.js';
import Product from './Product.js';
import Location from './Location.js';

const StockBalance = sequelize.define('StockBalance', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  product_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  location_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  qty: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
  reserved: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0,
  },
}, {
  tableName: 'stock_balances',
  timestamps: true,
  indexes: [
    { unique: true, fields: ['product_id', 'location_id'] },
  ],
});

StockBalance.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });
StockBalance.belongsTo(Location, { foreignKey: 'location_id', as: 'location' });
Product.hasMany(StockBalance, { foreignKey: 'product_id', as: 'stockBalances' });

export default StockBalance;