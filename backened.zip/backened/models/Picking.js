import { DataTypes } from 'sequelize';
import { sequelize } from '../config/db.js';
import User from './User.js';

const Picking = sequelize.define('Picking', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  reference: {
    type: DataTypes.STRING,
    unique: true,
  },
  type: {
    type: DataTypes.ENUM('incoming', 'outgoing', 'internal'),
    allowNull: false,
  },
  partner: {
    type: DataTypes.STRING,
  },
  scheduled_date: {
    type: DataTypes.DATE,
  },
  status: {
    type: DataTypes.ENUM('draft', 'ready', 'done', 'cancelled'),
    defaultValue: 'draft',
  },
  notes: {
    type: DataTypes.TEXT,
  },
  created_by: {
    type: DataTypes.INTEGER,
  },
}, {
  tableName: 'pickings',
  timestamps: true,
  hooks: {
    beforeCreate: async (picking) => {
      if (!picking.reference) {
        const prefix = picking.type === 'incoming' ? 'REC' : picking.type === 'outgoing' ? 'DEL' : 'INT';
        const count = await Picking.count({ where: { type: picking.type } });
        picking.reference = `${prefix}${String(count + 1).padStart(5, '0')}`;
      }
    },
  },
});

Picking.belongsTo(User, { foreignKey: 'created_by', as: 'creator' });

export default Picking;